import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    Patch,
    Post,
    Query,
  } from '@nestjs/common';
  
  import { ProductsService } from '../services/products.service';
  
  import { CreateProductDto } from '../dto/create-product.dto';
  import { UpdateProductDto } from '../dto/update-product.dto';
  import { ProductFilterDto } from '../dto/product-filter.dto';
  
  @Controller('products')
  export class ProductsController {
    constructor(
      private readonly productsService: ProductsService,
    ) {}
  
    @Post()
    create(
      @Body() createProductDto: CreateProductDto,
    ) {
      return this.productsService.create(createProductDto);
    }
  
    @Get()
    findAll(
      @Query() filter: ProductFilterDto,
    ) {
      return this.productsService.findAll(filter);
    }
  
    @Get(':id')
    findOne(
      @Param('id') id: string,
    ) {
      return this.productsService.findOne(id);
    }
  
    @Patch(':id')
    update(
      @Param('id') id: string,
      @Body() updateProductDto: UpdateProductDto,
    ) {
      return this.productsService.update(
        id,
        updateProductDto,
      );
    }
  
    @Delete(':id')
    remove(
      @Param('id') id: string,
    ) {
      return this.productsService.remove(id);
    }
  }